package com.example.plantdisease_app;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;


public interface ApiService {

    @Multipart
    @POST("upload")
    Call<ResponseBody> uploadImage(
            @Part MultipartBody.Part image
    );
    {
       // RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), imageFile);

       // RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        //MultipartBody.Part body = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
    }
}