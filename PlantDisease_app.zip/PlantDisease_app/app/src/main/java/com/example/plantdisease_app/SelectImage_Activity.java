package com.example.plantdisease_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class SelectImage_Activity extends AppCompatActivity {


    private Button SendImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_image);

        ImageView imageView = findViewById(R.id.imageView);

        Intent intent = getIntent();
        String imageUriString = intent.getStringExtra("imagem_uri");

        if (imageUriString != null) {
            Uri imageUri = Uri.parse(imageUriString);
            imageView.setImageURI(imageUri);
            String imagePath = imageUri.getPath();
            File file = new File(imagePath); // Convert Uri to File

        }


        SendImage = findViewById(R.id.button_sendImage);
        SendImage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ CallRetrofit(); }

        });
    }
    private void CallRetrofit(){

    }
}
